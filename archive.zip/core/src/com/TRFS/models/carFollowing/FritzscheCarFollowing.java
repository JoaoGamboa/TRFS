package com.TRFS.models.carFollowing;

import com.TRFS.ui.general.parameters.DynamicSimParam;
import com.TRFS.vehicles.Vehicle;

public class FritzscheCarFollowing extends CarFollowingModel{
	
	public static DynamicSimParam[] calibrationParameters = {};

	public FritzscheCarFollowing(Vehicle vehicle) {
		super(vehicle);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float update() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
