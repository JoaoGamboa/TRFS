package com.TRFS.scenarios.editor;

public class NodeAtributes {

}
